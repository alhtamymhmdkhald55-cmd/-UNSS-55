# أُنْس | UNSS

مشروع تطبيق أُنْس مبني بواجهة ويب محلية داخل `www/` ويستخدم Capacitor 6 لتجهيزه كتطبيق Android.

## البناء محلياً

يتطلب Node.js 20 و Java 17 و Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

ينتج ملف الاختبار عادةً في:
`android/app/build/outputs/apk/debug/app-debug.apk`

## البناء عبر GitHub Actions

بعد رفع هذه الملفات إلى الفرع `main`، افتح تبويب **Actions** في GitHub واختر **Build Anis Android APK** ثم **Run workflow**. يمكن تنزيل APK الناتج من قسم Artifacts بعد نجاح البناء.

## ملاحظات

- مجلد `android/` غير مضمّن في الأرشيف الأصلي؛ لذلك ينشئه سير العمل تلقائياً باستخدام Capacitor.
- ملف الواجهة `www/index.html` يعتمد على ملفات CSS وJavaScript الموجودة داخل `www/`، لذا يجب إبقاء بنية المجلد كما هي.
- يعتمد تحميل خطوط Cairo وAmiri وغيرها على اتصال الإنترنت لأن الخطوط مرتبطة بـ Google Fonts.
- لم يتم تغيير وظائف التطبيق أو محتوى القرآن/التفسير/الأحاديث أو بقية البيانات في هذه الحزمة.


## إشعارات الصلاة
- يتطلب المشروع إضافة Capacitor Local Notifications.
- تُجدول مواقيت الصلاة للأيام السبعة القادمة، مع تذكير بعد 15 دقيقة.
- يحتوي التذكير على خيار "نعم، صليت" أو "ذكرني بعد 10 دقائق".
- نغمة الإشعار نغمة قصيرة غير ناطقة مدتها نحو 2.4 ثانية.
- الأذان الحالي `www/assets/adhan.mp3` لم يتم استبداله.
- يجب تثبيت APK ومنح إذن الإشعارات. وقد تؤثر قيود البطارية/التنبيهات الدقيقة في توقيت بعض الأجهزة.

## أيقونة التطبيق وأصوات الإشعارات
- تم اعتماد الأيقونة المرفقة كأيقونة التطبيق وواجهة الويب.
- يمكن اختيار واحدة من خمس نغمات إشعار قصيرة غير ناطقة من صفحة الإشعارات، مع زر لمعاينة النغمة.
- عند تغيير النغمة يعاد جدولة إشعارات الصلاة القادمة باستخدام قناة Android خاصة بالنغمة المختارة.
- ينسخ سير العمل أيقونات التطبيق وجميع ملفات النغمات إلى موارد Android أثناء البناء.


## تحسينات الإشعارات والأذان
- ترتيب شاشة الإشعارات إلى أقسام مستقلة وواضحة.
- اختيار نغمة الإشعار يشغّل معاينتها مباشرة، ويحفظ الاختيار ويعيد جدولة التنبيهات.
- إضافة جدولة محلية للأذان للأيام السبعة القادمة باستخدام قناة أندرويد مخصصة وصوت الأذان الموجود في assets.
- إضافة إذن SCHEDULE_EXACT_ALARM إلى Android Manifest في بناء GitHub Actions.
- يجب السماح بإشعارات التطبيق وإذن «المنبّهات والتذكيرات» من إعدادات أندرويد. الإيقاف الإجباري للتطبيق (Force stop) يمنع أندرويد من تسليم المنبهات حتى فتح التطبيق مجددًا.


## آخر تعديلات
- إزالة زر الإشعار التجريبي وتنظيف شاشة الإشعارات (زر تشغيل رئيسي + أزرار تشغيل/إيقاف لكل خيار، رمادي عند الإيقاف).
- عند تفعيل الإشعارات وقبول الإذن تُفعَّل تلقائيًا: إشعارات الصلاة، الأذان، وتذكير الأذكار.
- شعار التطبيق في الإشعارات (أيقونة صغيرة وأيقونة كبيرة) — الملفات في `resources/drawable-*`.
- لفظ الجلالة وأسماء الله الحسنى (قائمة منتقاة) بالأحمر في كل السور.


## Native full-screen Adhan screen

The Android build workflow installs a native Capacitor plugin, exact-alarm receiver, and full-screen Android Activity. When Adhan notifications are enabled, the app schedules the upcoming seven days of prayer alarms. At prayer time Android displays the full-screen Adhan screen over apps and on the lock screen where the device permits full-screen intents. The screen uses the app launcher logo, the prayer name, the cyan Adhan line, and a red X close button at the bottom.

On Android 14 and newer, the system may require the user to allow full-screen notifications for أُنْس in Android app notification settings. Exact alarms also depend on the device's alarm permission and battery settings.


إصلاح إضافي: تمت إضافة معالجة زر الرجوع في أندرويد للتنقل إلى الشاشة السابقة داخل التطبيق بدل الخروج منه عند وجود صفحة داخلية.
